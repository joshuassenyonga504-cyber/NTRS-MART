import { Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import type { Product } from "@/lib/store-data";
import { effectivePrice, discountPercent } from "@/lib/store-data";
import { formatUGX } from "@/lib/format";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { variantsQuery } from "@/lib/store-data";
export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart(); const soldOut = product.stock <= 0; const sale = discountPercent(product);
  const navigate = useNavigate();
  const { data: variants = [], isLoading: variantsLoading } = useQuery(variantsQuery(product.id));
  return <article className="flex flex-col overflow-hidden rounded-lg bg-card shadow-card">
    <Link to="/products/$id" params={{ id: product.id }} className="relative block aspect-square w-full overflow-hidden bg-muted">
      {product.image_url ? <img src={product.image_url} alt={product.name} loading="lazy" className="size-full object-cover" /> : <div className="grid size-full place-items-center text-xs text-muted-foreground">No image</div>}
      {soldOut ? <span className="absolute left-2 top-2 rounded bg-foreground px-2 py-1 text-xs text-background">Sold out</span> : sale > 0 ? <span className="absolute left-2 top-2 rounded bg-accent px-2 py-1 text-xs font-bold text-accent-foreground">{sale}% OFF</span> : null}
    </Link>
    <div className="flex flex-1 flex-col gap-1 p-3">
      {product.category && <span className="text-xs uppercase text-muted-foreground">{product.category}</span>}
      <Link to="/products/$id" params={{ id: product.id }} className="line-clamp-2 text-sm font-semibold">{product.name}</Link>
      <div className="mt-auto flex items-end justify-between gap-2 pt-2">
        <div className="min-w-0"><span className="block font-display text-base font-bold text-primary">{formatUGX(effectivePrice(product))}</span>{sale > 0 && <span className="text-xs text-muted-foreground line-through">{formatUGX(product.price)}</span>}</div>
        <Button size="icon" variant="secondary" disabled={soldOut || variantsLoading} onClick={() => { if (variants.length) { void navigate({ to: "/products/$id", params: { id: product.id } }); return; } add({ id: product.id, name: product.name, price: effectivePrice(product), image_url: product.image_url }); toast.success(`${product.name} added to cart`); }} aria-label={variants.length ? `Choose colour for ${product.name}` : `Add ${product.name} to cart`} title={variants.length ? "Choose colour" : "Add to cart"} className="size-10 shrink-0"><Plus className="size-5" /></Button>
      </div>
    </div>
  </article>;
}

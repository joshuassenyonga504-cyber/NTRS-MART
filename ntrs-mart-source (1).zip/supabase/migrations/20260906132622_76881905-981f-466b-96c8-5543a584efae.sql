-- Idempotent repair of the NTRS.MART schema after partial restore.
-- No DROP of tables/types/data. Everything below is safe to re-run.

-- 1. Ensure the role enum exists (do not recreate if present)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace
                 WHERE t.typname = 'app_role' AND n.nspname = 'public') THEN
    CREATE TYPE public.app_role AS ENUM ('admin', 'user');
  END IF;
END $$;

-- 2. Ensure RLS stays enabled everywhere
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 3. Re-grant Data API privileges (these were lost in the restore)
GRANT SELECT ON public.products TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;

GRANT SELECT ON public.delivery_zones TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.delivery_zones TO authenticated;
GRANT ALL ON public.delivery_zones TO service_role;

GRANT INSERT ON public.orders TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;

GRANT INSERT ON public.order_items TO anon;
GRANT SELECT, INSERT ON public.order_items TO authenticated;
GRANT ALL ON public.order_items TO service_role;

GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;

-- 4. Guest + shopper checkout without privileged credentials
DROP POLICY IF EXISTS "Guests can place orders" ON public.orders;
CREATE POLICY "Guests can place orders"
ON public.orders FOR INSERT TO anon
WITH CHECK (
  user_id IS NULL
  AND status = 'pending'
  AND payment_status IN ('pending', 'awaiting_payment')
);

DROP POLICY IF EXISTS "Shoppers can place orders" ON public.orders;
CREATE POLICY "Shoppers can place orders"
ON public.orders FOR INSERT TO authenticated
WITH CHECK (
  (user_id IS NULL OR user_id = auth.uid())
  AND status = 'pending'
  AND payment_status IN ('pending', 'awaiting_payment')
);

DROP POLICY IF EXISTS "Guests can add order items" ON public.order_items;
CREATE POLICY "Guests can add order items"
ON public.order_items FOR INSERT TO anon
WITH CHECK (
  EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.user_id IS NULL)
);

DROP POLICY IF EXISTS "Shoppers can add order items" ON public.order_items;
CREATE POLICY "Shoppers can add order items"
ON public.order_items FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.orders o
    WHERE o.id = order_id AND (o.user_id IS NULL OR o.user_id = auth.uid())
  )
);

-- 5. Keep the admin check locked down to signed-in callers only
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;

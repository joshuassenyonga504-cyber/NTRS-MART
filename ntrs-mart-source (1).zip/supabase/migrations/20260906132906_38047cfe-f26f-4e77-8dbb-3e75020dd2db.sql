-- Helper so the order-items rule can verify the parent order without
-- needing read access to the orders table.
CREATE OR REPLACE FUNCTION public.can_add_items_to_order(_order_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.orders o
    WHERE o.id = _order_id
      AND o.status = 'pending'
      AND (o.user_id IS NULL OR o.user_id = auth.uid())
      AND o.created_at > now() - interval '15 minutes'
  )
$$;

REVOKE EXECUTE ON FUNCTION public.can_add_items_to_order(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.can_add_items_to_order(uuid) TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "Guests can add order items" ON public.order_items;
CREATE POLICY "Guests can add order items"
ON public.order_items FOR INSERT TO anon
WITH CHECK (public.can_add_items_to_order(order_id));

DROP POLICY IF EXISTS "Shoppers can add order items" ON public.order_items;
CREATE POLICY "Shoppers can add order items"
ON public.order_items FOR INSERT TO authenticated
WITH CHECK (public.can_add_items_to_order(order_id));

-- Clean up the verification order.
DELETE FROM public.order_items WHERE order_id IN (SELECT id FROM public.orders WHERE customer_name = 'Test Buyer');
DELETE FROM public.orders WHERE customer_name = 'Test Buyer';

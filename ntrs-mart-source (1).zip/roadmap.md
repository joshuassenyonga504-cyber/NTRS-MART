# NTRS.MART roadmap

## Checkout
- [x] Cash on Delivery is the only payment method
- [x] Online payment (Flutterwave) removed entirely — no code, routes or keys
- [x] Delivery areas with per-area delivery fee
- [x] Order + order items saved server-side with prices from the database

## Storefront
- [x] Products load dynamically from the database
- [x] Search, product cards, add to cart, cart, checkout

## Admin (/admin)
- [x] Add / edit / delete products
- [x] Upload and change product images
- [x] Orders and users management

## Current upgrade
- [x] Uploaded brand image and Shop Now homepage
- [x] Promotions with admin management and scheduling
- [x] Discounts, product details, galleries, variants and order snapshots
- [x] Statuses and archived orders
- [x] WhatsApp support floating button on all storefront pages
- [x] Mobile and cash-on-delivery end-to-end verification

## Welcome experience
- [x] Four-slide full-screen mobile welcome carousel
- [x] Swipe, pagination, skip, continue and shopping actions
- [x] One-time display remembered on the customer device
- [x] Admin-managed welcome slides and image uploads
- [x] Optional per-slide button actions and customer re-introduction via versioned completion key

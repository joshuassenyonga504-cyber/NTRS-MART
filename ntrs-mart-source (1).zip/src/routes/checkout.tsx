import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { ArrowLeft, Banknote, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { zonesQuery } from "@/lib/store-data";
import { placeOrder } from "@/lib/orders.functions";
import { useCart } from "@/lib/cart";
import { formatUGX } from "@/lib/format";
import { WhatsAppFab } from "@/components/store/whatsapp-button";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — NTRS.MART" },
      {
        name: "description",
        content:
          "Enter your delivery location and pay cash to the rider when your NTRS.MART order arrives.",
      },
      { property: "og:title", content: "Checkout — NTRS.MART" },
      {
        property: "og:description",
        content: "Confirm your delivery details and place your NTRS.MART order.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const navigate = useNavigate();
  const { items, subtotal, clear } = useCart();
  const { data: zones = [], isLoading: zonesLoading } = useQuery(zonesQuery);
  const submitOrder = useServerFn(placeOrder);


  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [zoneId, setZoneId] = useState("");
  const [address, setAddress] = useState("");
  const [landmark, setLandmark] = useState("");
  const [notes, setNotes] = useState("");
  
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!zoneId && zones.length > 0) setZoneId(zones[0]!.id);
  }, [zones, zoneId]);

  const zone = zones.find((z) => z.id === zoneId);
  const deliveryFee = zone ? Number(zone.fee) : 0;
  const total = subtotal + deliveryFee;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    if (name.trim().length < 2) {
      toast.error("Please enter your full name.");
      return;
    }
    if (phone.trim().length < 7) {
      toast.error("Please enter a valid phone number.");
      return;
    }
    if (!zoneId) {
      toast.error("Please choose your delivery area.");
      return;
    }
    if (address.trim().length < 3) {
      toast.error("Please enter your delivery address.");
      return;
    }

    setSubmitting(true);
    try {
      const result = await submitOrder({
        data: {
          customer_name: name.trim(),
          customer_phone: phone.trim(),
          zone_id: zoneId,
          address: address.trim(),
          landmark: landmark.trim(),
          notes: notes.trim(),
          items: items.map((i) => ({ product_id: i.id, quantity: i.quantity, variant_id: i.variant_id ?? null })),
        },
      });
      window.sessionStorage.setItem("ntrsmart.lastOrder", JSON.stringify(result));
      clear();
      void navigate({ to: "/order-success" });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not place your order.");
    } finally {
      setSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="grid min-h-screen place-items-center px-6 text-center">
        <div>
          <p className="text-sm text-muted-foreground">Your cart is empty.</p>
          <Button asChild className="mt-4 h-12 rounded-xl px-6">
            <Link to="/">Browse products</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-40">
      <header className="sticky top-0 z-30 flex items-center gap-3 bg-primary px-4 py-4 text-primary-foreground shadow-lg">
        <Link to="/cart" aria-label="Back to cart">
          <ArrowLeft className="size-5" />
        </Link>
        <h1 className="font-display text-lg font-bold">Checkout</h1>
      </header>

      <form onSubmit={handleSubmit} className="mx-auto max-w-3xl space-y-4 px-4 pt-4">
        <section className="space-y-3 rounded-2xl bg-card p-4 shadow-card">
          <h2 className="font-display text-base font-bold">Your details</h2>
          <div className="space-y-1.5">
            <Label htmlFor="name">Full name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
              placeholder="e.g. Ssenyonga Joshua"
              className="h-12 rounded-xl"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="phone">Phone number</Label>
            <Input
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              placeholder="07XX XXX XXX"
              className="h-12 rounded-xl"
            />
          </div>
        </section>

        <section className="space-y-3 rounded-2xl bg-card p-4 shadow-card">
          <h2 className="font-display text-base font-bold">Delivery location</h2>
          {zonesLoading ? (
            <p className="text-sm text-muted-foreground">Loading areas…</p>
          ) : (
            <div className="grid gap-2">
              {zones.map((z) => (
                <button
                  key={z.id}
                  type="button"
                  onClick={() => setZoneId(z.id)}
                  className={cn(
                    "flex items-center justify-between gap-3 rounded-xl border px-3.5 py-3 text-left text-sm transition",
                    zoneId === z.id ? "border-primary bg-secondary" : "border-border",
                  )}
                >
                  <span className="font-semibold">{z.name}</span>
                  <span className="shrink-0 text-xs font-bold text-primary">
                    {formatUGX(z.fee)}
                  </span>
                </button>
              ))}
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="address">Street / village / area</Label>
            <Input
              id="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. Plot 12, Kira Road, Kamwokya"
              className="h-12 rounded-xl"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="landmark">Nearest landmark (optional)</Label>
            <Input
              id="landmark"
              value={landmark}
              onChange={(e) => setLandmark(e.target.value)}
              placeholder="e.g. opposite Shell Kamwokya"
              className="h-12 rounded-xl"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="notes">Delivery notes (optional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Call when you reach the gate"
              className="rounded-xl"
            />
          </div>
        </section>

        <section className="space-y-2 rounded-2xl bg-card p-4 shadow-card">
          <h2 className="font-display text-base font-bold">Payment</h2>
          <div className="flex items-start gap-3 rounded-xl border border-primary bg-secondary px-3.5 py-3">
            <Banknote className="mt-0.5 size-5 text-primary" />
            <span>
              <span className="block text-sm font-semibold">Cash on delivery</span>
              <span className="block text-xs text-muted-foreground">
                Pay the rider in cash when your order arrives
              </span>
            </span>
          </div>
        </section>

        <section className="space-y-2 rounded-2xl bg-card p-4 text-sm shadow-card">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Items subtotal</span>
            <span className="font-semibold">{formatUGX(subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">
              Delivery{zone ? ` — ${zone.name}` : ""}
            </span>
            <span className="font-semibold">{formatUGX(deliveryFee)}</span>
          </div>
          <div className="flex justify-between border-t border-border pt-2">
            <span className="font-bold">Total</span>
            <span className="font-display text-lg font-extrabold text-primary">
              {formatUGX(total)}
            </span>
          </div>
        </section>

        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/95 p-4 backdrop-blur">
          <div className="mx-auto max-w-3xl">
            <Button
              type="submit"
              disabled={submitting}
              className="h-13 w-full rounded-xl text-base font-bold"
            >
              {submitting ? <Loader2 className="size-5 animate-spin" /> : null}
              Place order · {formatUGX(total)}
            </Button>
          </div>
        </div>
      </form>
      <WhatsAppFab aboveBar />
    </div>
  );
}

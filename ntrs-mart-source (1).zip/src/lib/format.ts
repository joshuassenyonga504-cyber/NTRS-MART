export function formatUGX(amount: number): string {
  const rounded = Math.round(Number(amount) || 0);
  return `UGX ${rounded.toLocaleString("en-UG")}`;
}

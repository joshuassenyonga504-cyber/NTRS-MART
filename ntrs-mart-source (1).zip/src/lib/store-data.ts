import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Product = {
  id: string; name: string; description: string | null; price: number;
  sale_price: number | null; discount_active: boolean; image_url: string | null;
  images: string[]; category: string | null; stock: number; is_active: boolean;
};
export type Variant = { id: string; product_id: string; name: string; images: string[]; sort_order: number };
export type Promotion = { id: string; headline: string; description: string; promotional_text: string; image_url: string | null; starts_at: string | null; ends_at: string | null; sort_order: number; is_active: boolean };
export type WelcomeSlide = { id: string; headline: string; description: string; image_url: string | null; button_label: string | null; button_url: string | null; sort_order: number; is_active: boolean };
export type DeliveryZone = { id: string; name: string; fee: number; sort_order: number; is_active: boolean };
export const effectivePrice = (p: Product) => p.discount_active && p.sale_price !== null && Number(p.sale_price) < Number(p.price) ? Number(p.sale_price) : Number(p.price);
export const discountPercent = (p: Product) => Math.round((1 - effectivePrice(p) / Number(p.price)) * 100) || 0;
const productColumns = "id, name, description, price, sale_price, discount_active, image_url, images, category, stock, is_active";
export const productsQuery = queryOptions({ queryKey: ["products", "active"], queryFn: async (): Promise<Product[]> => {
  const { data, error } = await supabase.from("products").select(productColumns).eq("is_active", true).order("created_at", { ascending: false });
  if (error) throw error; return (data ?? []) as Product[];
}});
export const allProductsQuery = queryOptions({ queryKey: ["products", "all"], queryFn: async (): Promise<Product[]> => {
  const { data, error } = await supabase.from("products").select(productColumns).order("created_at", { ascending: false });
  if (error) throw error; return (data ?? []) as Product[];
}});
export const variantsQuery = (productId: string) => queryOptions({ queryKey: ["variants", productId], queryFn: async (): Promise<Variant[]> => {
  const { data, error } = await supabase.from("product_variants").select("id, product_id, name, images, sort_order").eq("product_id", productId).order("sort_order");
  if (error) throw error; return (data ?? []) as Variant[];
}});
export const promotionsQuery = queryOptions({ queryKey: ["promotions", "current"], queryFn: async (): Promise<Promotion[]> => {
  const now = new Date().toISOString();
  const { data, error } = await supabase.from("homepage_promotions").select("*").eq("is_active", true).or(`starts_at.is.null,starts_at.lte.${now}`).or(`ends_at.is.null,ends_at.gte.${now}`).order("sort_order");
  if (error) throw error; return (data ?? []) as Promotion[];
}});
export const welcomeSlidesQuery = queryOptions({ queryKey: ["welcome-slides", "active"], queryFn: async (): Promise<WelcomeSlide[]> => {
  const { data, error } = await supabase.from("welcome_slides").select("id, headline, description, image_url, button_label, button_url, sort_order, is_active").eq("is_active", true).order("sort_order");
  if (error) throw error; return data ?? [];
}});
export const zonesQuery = queryOptions({ queryKey: ["delivery_zones"], queryFn: async (): Promise<DeliveryZone[]> => {
  const { data, error } = await supabase.from("delivery_zones").select("id, name, fee, sort_order, is_active").eq("is_active", true).order("sort_order", { ascending: true });
  if (error) throw error; return (data ?? []) as DeliveryZone[];
}});
export const allZonesQuery = queryOptions({ queryKey: ["delivery_zones", "all"], queryFn: async (): Promise<DeliveryZone[]> => {
  const { data, error } = await supabase.from("delivery_zones").select("id, name, fee, sort_order, is_active").order("sort_order", { ascending: true });
  if (error) throw error; return (data ?? []) as DeliveryZone[];
}});

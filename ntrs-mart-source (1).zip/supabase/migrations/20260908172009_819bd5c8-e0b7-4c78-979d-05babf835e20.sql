ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS payment_provider text,
  ADD COLUMN IF NOT EXISTS payment_reference text,
  ADD COLUMN IF NOT EXISTS payment_transaction_id text,
  ADD COLUMN IF NOT EXISTS paid_at timestamptz;

CREATE INDEX IF NOT EXISTS orders_payment_reference_idx ON public.orders (payment_reference);

DROP POLICY IF EXISTS "Guests can place orders" ON public.orders;
CREATE POLICY "Guests can place orders" ON public.orders
  FOR INSERT TO anon
  WITH CHECK (
    user_id IS NULL
    AND status = 'pending'
    AND payment_status = ANY (ARRAY['pending','awaiting_payment'])
    AND paid_at IS NULL
  );

DROP POLICY IF EXISTS "Shoppers can place orders" ON public.orders;
CREATE POLICY "Shoppers can place orders" ON public.orders
  FOR INSERT TO authenticated
  WITH CHECK (
    (user_id IS NULL OR user_id = auth.uid())
    AND status = 'pending'
    AND payment_status = ANY (ARRAY['pending','awaiting_payment'])
    AND paid_at IS NULL
  );
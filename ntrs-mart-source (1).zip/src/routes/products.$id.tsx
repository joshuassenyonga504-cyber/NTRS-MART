import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { ArrowLeft, Minus, Plus, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { productsQuery, variantsQuery, effectivePrice, discountPercent } from "@/lib/store-data";
import { useCart } from "@/lib/cart";
import { WhatsAppFab } from "@/components/store/whatsapp-button";
import { ProductCard } from "@/components/store/product-card";
import { formatUGX } from "@/lib/format";
import { Button } from "@/components/ui/button";
export const Route = createFileRoute("/products/$id")({
  head: () => ({ meta: [{ title: "Product details — NTRS.MART" }, { name: "description", content: "Explore product photos, colours and prices at NTRS.MART." }, { property: "og:title", content: "Product details — NTRS.MART" }, { property: "og:description", content: "Shop product details and variants at NTRS.MART." }, { property: "og:type", content: "product" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: ProductDetails,
});
function ProductDetails() {
  const { id } = Route.useParams(); const { data: products = [] } = useQuery(productsQuery);
  const { data: variants = [] } = useQuery(variantsQuery(id)); const { add } = useCart();
  const [selected, setSelected] = useState<string | null>(null); const [photo, setPhoto] = useState(0); const [quantity, setQuantity] = useState(1);
  useEffect(() => { setSelected(null); setPhoto(0); setQuantity(1); }, [id]);
  const product = products.find(p => p.id === id);
  if (!product) return <div className="mx-auto max-w-3xl p-6"><Link to="/">← Back to shop</Link><p className="mt-10">This product is unavailable.</p></div>;
  const variant = variants.find(v => v.id === selected);
  const productImages = [product.image_url, ...(product.images ?? [])].filter((url): url is string => Boolean(url));
  const images = variant?.images.length ? variant.images : productImages;
  const recommendations = products.filter(p => p.id !== id && p.category === product.category).slice(0, 4);
  const sale = discountPercent(product);
  let swipeStart = 0;
  return <div className="min-h-screen pb-24">
    <header className="sticky top-0 z-30 flex items-center gap-4 bg-primary px-4 py-3 text-primary-foreground"><Link to="/" aria-label="Back to shop"><ArrowLeft /></Link><span className="min-w-0 truncate font-display font-bold">NTRS.MART</span><Link to="/cart" className="ml-auto" aria-label="Open cart"><ShoppingBag /></Link></header>
    <main className="mx-auto max-w-3xl">
      <div className="relative aspect-square max-h-[560px] bg-muted sm:mx-4 sm:mt-4 sm:rounded-lg" onTouchStart={e => { swipeStart = e.touches[0]?.clientX ?? 0; }} onTouchEnd={e => { const delta = (e.changedTouches[0]?.clientX ?? swipeStart) - swipeStart; if (images.length > 1 && Math.abs(delta) > 45) setPhoto(i => (i + (delta < 0 ? 1 : images.length - 1)) % images.length); }}>
        {images[photo] ? <img src={images[photo]} alt={`${product.name}${variant ? ` in ${variant.name}` : ""} — image ${photo + 1}`} className="size-full object-contain" /> : <div className="grid size-full place-items-center text-muted-foreground">No image available</div>}
        {images.length > 1 && <div className="absolute inset-x-0 bottom-3 flex justify-center gap-2">{images.map((_, i) => <Button key={i} size="icon" variant={photo === i ? "default" : "secondary"} aria-label={`Show image ${i + 1}`} onClick={() => setPhoto(i)} className="size-8 rounded-full text-xs">{i + 1}</Button>)}</div>}
      </div>
      <div className="space-y-5 px-4 py-6">
        <div><p className="text-xs font-bold uppercase text-muted-foreground">{product.category}</p><h1 className="mt-1 font-display text-2xl font-bold">{product.name}</h1><div className="mt-2 flex flex-wrap items-center gap-3"><span className="text-xl font-bold text-primary">{formatUGX(effectivePrice(product))}</span>{sale > 0 && <><span className="text-sm text-muted-foreground line-through">{formatUGX(product.price)}</span><span className="rounded bg-accent px-2 py-1 text-xs font-bold text-accent-foreground">{sale}% OFF</span></>}</div><p className="mt-2 text-sm font-semibold text-muted-foreground">{product.stock > 0 ? `${product.stock} available` : "Sold out"}</p></div>
        {variants.length > 0 && <div><h2 className="mb-2 text-sm font-bold">Choose colour / variant {variant && `— ${variant.name}`}</h2><div className="flex flex-wrap gap-2">{variants.map(v => <Button key={v.id} type="button" variant={selected === v.id ? "default" : "outline"} onClick={() => { setSelected(v.id); setPhoto(0); }} className="h-12 gap-2 rounded-md">{v.images[0] && <img src={v.images[0]} alt="" className="size-7 rounded object-cover" />}{v.name}</Button>)}</div></div>}
        <div><h2 className="mb-2 text-sm font-bold">About this product</h2><p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{product.description || "No description available."}</p></div>
        <div className="flex items-center gap-3"><div className="flex h-12 items-center rounded-md border border-border"><Button size="icon" variant="ghost" aria-label="Decrease quantity" onClick={() => setQuantity(Math.max(1, quantity - 1))}><Minus className="size-4" /></Button><span className="w-9 text-center font-bold">{quantity}</span><Button size="icon" variant="ghost" aria-label="Increase quantity" onClick={() => setQuantity(Math.min(Math.min(product.stock, 99), quantity + 1))}><Plus className="size-4" /></Button></div><Button disabled={product.stock <= 0 || (variants.length > 0 && !variant)} className="h-12 flex-1" onClick={() => { add({ id: product.id, name: product.name, price: effectivePrice(product), image_url: images[0] ?? product.image_url, variant_id: variant?.id ?? null, variant_name: variant?.name ?? null }, quantity); toast.success("Added to cart"); }}>{variants.length > 0 && !variant ? "Select a colour" : "Add to cart"}</Button></div>
      </div>
      {recommendations.length > 0 && <section className="border-t border-border px-4 py-8"><h2 className="mb-4 font-display text-lg font-bold">You may also like</h2><div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{recommendations.map(p => <ProductCard key={p.id} product={p} />)}</div></section>}
    </main>
    <WhatsAppFab />
  </div>;
}

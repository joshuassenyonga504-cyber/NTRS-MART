<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep public catalogue, promotions, and variants on the existing Supabase client with RLS; admin writes use authenticated server functions to preserve role enforcement.
- Snapshot selected variant name and effective database price into order items at placement, so historic orders remain accurate.
- Store product and variant images as signed URLs in the existing private image bucket; no second storage system is needed.
- Keep welcome slides database-driven with safe per-slide actions; show the carousel once per app session via sessionStorage — not on refreshes within a session, but again after the app is closed and reopened (owner preference).

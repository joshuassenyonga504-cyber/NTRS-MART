import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2, ArrowLeft } from "lucide-react";
import { cartKey, useCart } from "@/lib/cart";
import { formatUGX } from "@/lib/format";
import { WhatsAppFab } from "@/components/store/whatsapp-button";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your cart — NTRS.MART" },
      { name: "description", content: "Review the items in your NTRS.MART basket before checkout." },
      { property: "og:title", content: "Your cart — NTRS.MART" },
      { property: "og:description", content: "Review your NTRS.MART basket and check out." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { items, subtotal, setQuantity, remove } = useCart();

  return (
    <div className="min-h-screen pb-32">
      <header className="sticky top-0 z-30 flex items-center gap-3 bg-primary px-4 py-4 text-primary-foreground shadow-lg">
        <Link to="/" aria-label="Back to shop">
          <ArrowLeft className="size-5" />
        </Link>
        <h1 className="font-display text-lg font-bold">Your cart</h1>
      </header>

      <main className="mx-auto max-w-3xl px-4 pt-4">
        {items.length === 0 ? (
          <div className="py-20 text-center">
            <p className="text-sm text-muted-foreground">Your cart is empty.</p>
            <Button asChild className="mt-4 h-12 rounded-xl px-6">
              <Link to="/">Start shopping</Link>
            </Button>
          </div>
        ) : (
          <ul className="space-y-3">
            {items.map((item) => (
              <li key={cartKey(item)} className="flex gap-3 rounded-2xl bg-card p-3 shadow-card">
                <div className="size-20 shrink-0 overflow-hidden rounded-xl bg-muted">
                  {item.image_url && (
                    <img
                      src={item.image_url}
                      alt={item.name}
                      loading="lazy"
                      className="size-full object-cover"
                    />
                  )}
                </div>
                <div className="flex min-w-0 flex-1 flex-col">
                  <p className="line-clamp-2 text-sm font-semibold">{item.name}</p>
                  <p className="text-xs text-muted-foreground">{item.variant_name ? `Colour: ${item.variant_name}` : ""}</p>
                   <p className="text-sm font-bold text-primary">{formatUGX(item.price)} each · {formatUGX(item.price * item.quantity)}</p>
                  <div className="mt-auto flex items-center gap-2">
                    <button
                      type="button"
                      aria-label="Decrease quantity"
                      onClick={() => setQuantity(cartKey(item), item.quantity - 1)}
                      className="grid size-8 place-items-center rounded-lg border border-border active:scale-90"
                    >
                      <Minus className="size-4" />
                    </button>
                    <span className="w-6 text-center text-sm font-bold">{item.quantity}</span>
                    <button
                      type="button"
                      aria-label="Increase quantity"
                      onClick={() => setQuantity(cartKey(item), item.quantity + 1)}
                      className="grid size-8 place-items-center rounded-lg border border-border active:scale-90"
                    >
                      <Plus className="size-4" />
                    </button>
                    <button
                      type="button"
                      aria-label={`Remove ${item.name}`}
                      onClick={() => remove(cartKey(item))}
                      className="ml-auto grid size-8 place-items-center rounded-lg text-destructive active:scale-90"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>

      {items.length > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/95 p-4 backdrop-blur">
          <div className="mx-auto max-w-3xl">
            <div className="mb-3 flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Items subtotal</span>
              <span className="font-display text-lg font-bold">{formatUGX(subtotal)}</span>
            </div>
            <Button asChild className="h-13 w-full rounded-xl text-base font-bold">
              <Link to="/checkout">Checkout</Link>
            </Button>
            <p className="mt-2 text-center text-xs text-muted-foreground">
              Delivery fee is added at checkout based on your location.
            </p>
          </div>
        </div>
      )}
      <WhatsAppFab aboveBar={items.length > 0} />
    </div>
  );
}

CREATE TABLE IF NOT EXISTS public.welcome_slides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  headline text NOT NULL,
  description text NOT NULL DEFAULT '',
  image_url text,
  button_label text,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.welcome_slides TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.welcome_slides TO authenticated;
GRANT ALL ON public.welcome_slides TO service_role;

ALTER TABLE public.welcome_slides ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view active welcome slides" ON public.welcome_slides;
CREATE POLICY "Anyone can view active welcome slides"
ON public.welcome_slides
FOR SELECT
TO anon, authenticated
USING (is_active = true);

DROP POLICY IF EXISTS "Admins manage welcome slides" ON public.welcome_slides;
CREATE POLICY "Admins manage welcome slides"
ON public.welcome_slides
FOR ALL
TO authenticated
USING (private.is_admin(auth.uid()))
WITH CHECK (private.is_admin(auth.uid()));

DROP TRIGGER IF EXISTS set_welcome_slides_updated_at ON public.welcome_slides;
CREATE TRIGGER set_welcome_slides_updated_at
BEFORE UPDATE ON public.welcome_slides
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
export const WHATSAPP_NUMBER = "256757887536";

export const WHATSAPP_SUPPORT_MESSAGE =
  "Hello NTRS.MART, I need help with a product/order.";

export function whatsappSupportUrl(message: string = WHATSAPP_SUPPORT_MESSAGE) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

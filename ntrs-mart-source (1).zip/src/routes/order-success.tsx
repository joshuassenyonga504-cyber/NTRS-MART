import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { formatUGX } from "@/lib/format";
import { WhatsAppFab } from "@/components/store/whatsapp-button";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/order-success")({
  head: () => ({
    meta: [
      { title: "Order placed — NTRS.MART" },
      { name: "description", content: "Your NTRS.MART order has been received and is being prepared for delivery." },
      { property: "og:title", content: "Order placed — NTRS.MART" },
      { property: "og:description", content: "Your NTRS.MART order has been received." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: OrderSuccess,
});

type LastOrder = {
  order_id?: string;
  order_number?: string;
  total?: number;
  payment_method?: string;
  paid?: boolean;
};

function OrderSuccess() {
  const [order, setOrder] = useState<LastOrder | null>(null);

  useEffect(() => {
    const raw = window.sessionStorage.getItem("ntrsmart.lastOrder");
    if (raw) {
      try {
        setOrder(JSON.parse(raw) as LastOrder);
      } catch {
        setOrder(null);
      }
    }
  }, []);

  return (
    <div className="grid min-h-screen place-items-center px-6 py-16 text-center">
      <div className="max-w-sm">
        <CheckCircle2 className="mx-auto size-16 text-success" />
        <h1 className="mt-4 font-display text-2xl font-extrabold">Order received!</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Thank you for shopping with NTRS.MART. Our team will call you shortly to confirm your
          delivery.
        </p>

        <div className="mt-5 space-y-1 rounded-2xl bg-card p-4 text-left text-sm shadow-card">
          {order?.order_number && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Order</span>
              <span className="font-semibold">{order.order_number}</span>
            </div>
          )}
          {typeof order?.total === "number" && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total</span>
              <span className="font-bold text-primary">{formatUGX(order.total)}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Payment</span>
            <span className="font-semibold">Cash on delivery</span>
          </div>
          <div className="flex justify-between"><span className="text-muted-foreground">Status</span><span className="font-semibold">Pending confirmation</span></div>
        </div>

        <p className="mt-3 text-xs text-muted-foreground">
          Please have the exact amount ready in cash for the rider.
        </p>


        <Button asChild className="mt-6 h-12 w-full rounded-xl font-bold">
          <Link to="/">Continue shopping</Link>
        </Button>
        <div className="mt-4">
          <WhatsAppFab />
        </div>
      </div>
    </div>
  );
}

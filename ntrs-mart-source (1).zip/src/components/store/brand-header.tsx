import { Link } from "@tanstack/react-router";
import { ShoppingBasket, Search, ShieldCheck, LogOut } from "lucide-react";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function BrandMark({ className }: { className?: string }) {
  return (
    <Link to="/" className={cn("flex items-center gap-2", className)}>
      <span className="grid size-9 place-items-center rounded-xl bg-accent font-display text-lg font-extrabold text-accent-foreground">
        N
      </span>
      <span className="font-display text-xl font-extrabold tracking-tight text-primary-foreground">
        NTRS<span className="text-accent">.</span>MART
      </span>
    </Link>
  );
}

export function CartButton() {
  const { count } = useCart();
  return (
    <Link
      to="/cart"
      aria-label="Open cart"
      className="relative grid size-10 place-items-center rounded-xl bg-primary-foreground/10 text-primary-foreground transition active:scale-95"
    >
      <ShoppingBasket className="size-5" />
      {count > 0 && (
        <span className="absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-accent px-1 text-[11px] font-bold text-accent-foreground">
          {count}
        </span>
      )}
    </Link>
  );
}

export function SignOutButton() {
  const { user } = useAuth();
  if (!user) return null;
  return (
    <button
      type="button"
      aria-label="Sign out"
      onClick={() => void supabase.auth.signOut()}
      className="grid size-10 place-items-center rounded-xl bg-primary-foreground/10 text-primary-foreground transition active:scale-95"
    >
      <LogOut className="size-5" />
    </button>
  );
}

export function AdminLoginLink() {
  const { user, loading } = useAuth();
  if (loading || user) return null;
  return (
    <Link
      to="/auth"
      aria-label="Admin login"
      className="grid size-10 place-items-center rounded-xl bg-primary-foreground/10 text-primary-foreground"
    >
      <ShieldCheck className="size-5" />
    </Link>
  );
}

export function StoreHeader({
  query,
  onQueryChange,
  showAdminLink,
}: {
  query?: string;
  onQueryChange?: (value: string) => void;
  showAdminLink?: boolean;
}) {
  return (
    <header className="sticky top-0 z-30 bg-primary pb-3 pt-3 shadow-lg">
      <div className="mx-auto flex max-w-3xl items-center gap-3 px-4">
        <BrandMark />
        <div className="ml-auto flex items-center gap-2">
          {showAdminLink && (
            <Link
              to="/admin"
              aria-label="Admin dashboard"
              className="grid size-10 place-items-center rounded-xl bg-primary-foreground/10 text-primary-foreground"
            >
              <ShieldCheck className="size-5" />
            </Link>
          )}
          <AdminLoginLink />
          <SignOutButton />
          <CartButton />
        </div>
      </div>
      {onQueryChange && (
        <div className="mx-auto mt-3 max-w-3xl px-4">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query ?? ""}
              onChange={(e) => onQueryChange(e.target.value)}
              inputMode="search"
              placeholder="Search products…"
              className="h-12 rounded-xl border-0 bg-card pl-9 text-base shadow-card"
            />
          </div>
        </div>
      )}
    </header>
  );
}

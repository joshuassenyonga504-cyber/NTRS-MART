import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const orderInput = z.object({
  customer_name: z.string().trim().min(2).max(120),
  customer_phone: z.string().trim().min(7).max(30),
  zone_id: z.string().uuid(),
  address: z.string().trim().min(3).max(400),
  landmark: z.string().trim().max(200).optional().or(z.literal("")),
  notes: z.string().trim().max(500).optional().or(z.literal("")),
  
  items: z
    .array(
      z.object({
        product_id: z.string().uuid(),
        quantity: z.number().int().min(1).max(99),
        variant_id: z.string().uuid().nullable().optional(),
      }),
    )
    .min(1)
    .max(50),
});

export const placeOrder = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => orderInput.parse(data))
  .handler(async ({ data }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const supabaseUrl = process.env["SUPABASE_URL"] ?? process.env["VITE_SUPABASE_URL"];
    const supabaseKey =
      process.env["SUPABASE_PUBLISHABLE_KEY"] ?? process.env["VITE_SUPABASE_PUBLISHABLE_KEY"];
    if (!supabaseUrl || !supabaseKey) {
      throw new Error("The store is not connected to its database right now.");
    }
    const store = createClient(supabaseUrl, supabaseKey, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const headers = new Headers(init?.headers);
          if (supabaseKey.startsWith("sb_") && headers.get("Authorization") === `Bearer ${supabaseKey}`) {
            headers.delete("Authorization");
          }
          headers.set("apikey", supabaseKey);
          return fetch(input, { ...init, headers });
        },
      },
    });

    const ids = [...new Set(data.items.map((i) => i.product_id))];
    const { data: products, error: productsError } = await store
      .from("products")
      .select("id, name, price, sale_price, discount_active, is_active")
      .in("id", ids);
    if (productsError) throw new Error(productsError.message);

    const available = (products ?? []).filter((p) => p.is_active);
    if (available.length === 0) throw new Error("None of these products are available.");

    const { data: zone, error: zoneError } = await store
      .from("delivery_zones")
      .select("id, name, fee, is_active")
      .eq("id", data.zone_id)
      .maybeSingle();
    if (zoneError) throw new Error(zoneError.message);
    if (!zone || !zone.is_active) throw new Error("Please pick a valid delivery area.");

    const variantIds = [...new Set(data.items.map(i => i.variant_id).filter((id): id is string => Boolean(id)))];
    const { data: variants, error: variantsError } = variantIds.length
      ? await store.from("product_variants").select("id, product_id, name").in("id", variantIds)
      : { data: [], error: null };
    if (variantsError) throw new Error(variantsError.message);
    // Prices and variant names always come from the database, never from the browser.
    const lines = data.items
      .map((item) => {
        const product = available.find((p) => p.id === item.product_id);
        if (!product) return null;
        const variant = item.variant_id ? variants?.find(v => v.id === item.variant_id && v.product_id === product.id) : null;
        if (item.variant_id && !variant) throw new Error("Please choose an available product variant.");
        return {
          product_id: product.id,
          product_name: product.name,
          unit_price: product.discount_active && product.sale_price !== null && Number(product.sale_price) < Number(product.price) ? Number(product.sale_price) : Number(product.price),
          variant_name: variant?.name ?? null,
          quantity: item.quantity,
        };
      })
      .filter((l): l is NonNullable<typeof l> => l !== null);

    if (lines.length === 0) throw new Error("None of these products are available.");

    const subtotal = lines.reduce((sum, l) => sum + l.unit_price * l.quantity, 0);
    const deliveryFee = Number(zone.fee);
    const total = subtotal + deliveryFee;

    // Shoppers can create orders but cannot read them back, so ids are generated here.
    const orderId = crypto.randomUUID();
    const orderNumber = `NM-${orderId.replace(/-/g, "").slice(0, 8).toUpperCase()}`;

    const { error: orderError } = await store.from("orders").insert({
      id: orderId,
      order_number: orderNumber,
      customer_name: data.customer_name,
      customer_phone: data.customer_phone,
      zone_id: zone.id,
      zone_name: zone.name,
      address: data.address,
      landmark: data.landmark || null,
      notes: data.notes || null,
      subtotal,
      delivery_fee: deliveryFee,
      total,
      payment_method: "cod",
      payment_status: "pending",
      status: "pending",
    });
    if (orderError) throw new Error(orderError.message);

    const { error: itemsError } = await store
      .from("order_items")
      .insert(lines.map((l) => ({ ...l, order_id: orderId })));
    if (itemsError) throw new Error(itemsError.message);

    return {
      order_id: orderId,
      order_number: orderNumber,
      subtotal,
      delivery_fee: deliveryFee,
      total,
      payment_method: "cod" as const,
      zone_name: zone.name,
    };
  });

import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Truck, BadgeCheck, Wallet } from "lucide-react";
import { productsQuery, promotionsQuery, welcomeSlidesQuery } from "@/lib/store-data";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/store/product-card";
import { StoreHeader } from "@/components/store/brand-header";
import { WhatsAppFab } from "@/components/store/whatsapp-button";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import brandImage from "@/assets/ntrsmart-brand.png.asset.json";
import { WelcomeExperience, WELCOME_SESSION_KEY } from "@/components/store/welcome-experience";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NTRS.MART — Shop groceries & essentials in Uganda" },
      {
        name: "description",
        content:
           "Browse NTRS.MART for groceries, electronics and home essentials. Delivery across Kampala and upcountry, cash on delivery.",
      },
      { property: "og:title", content: "NTRS.MART — Shop & get it delivered in Uganda" },
      {
        property: "og:description",
        content: "Groceries, electronics and home essentials delivered across Uganda.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQuery),
  component: Storefront,
  errorComponent: () => (
    <div className="p-8 text-center text-sm text-muted-foreground">
      We couldn&apos;t load the shop. Please refresh.
    </div>
  ),
});

function Storefront() {
  const { data: products } = useSuspenseQuery(productsQuery);
  const { isAdmin } = useAuth();
  const { data: promotions = [] } = useQuery(promotionsQuery);
  const { data: welcomeSlides = [] } = useQuery(welcomeSlidesQuery);
  const [showWelcome, setShowWelcome] = useState(false);
  const [promotionIndex, setPromotionIndex] = useState(0);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("All");

  useEffect(() => {
    // Show the welcome carousel once per app session: it is not shown again
    // on refreshes within the same session, but reappears after the app is
    // closed and reopened (session storage is cleared on close).
    if (sessionStorage.getItem(WELCOME_SESSION_KEY)) return;
    sessionStorage.setItem(WELCOME_SESSION_KEY, "shown");
    setShowWelcome(true);
  }, []);

  const categories = useMemo(
    () => ["All", ...[...new Set(products.map((p) => p.category).filter(Boolean))]] as string[],
    [products],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      const matchesQuery =
        !q ||
        p.name.toLowerCase().includes(q) ||
        (p.description ?? "").toLowerCase().includes(q) ||
        (p.category ?? "").toLowerCase().includes(q);
      const matchesCategory = category === "All" || p.category === category;
      return matchesQuery && matchesCategory;
    });
  }, [products, query, category]);

  return (
    <div className="min-h-screen pb-16">
      {showWelcome && welcomeSlides.length > 0 ? (
        <WelcomeExperience slides={welcomeSlides} onComplete={() => setShowWelcome(false)} />
      ) : null}
      <StoreHeader query={query} onQueryChange={setQuery} showAdminLink={isAdmin} />

      <section className="bg-primary pb-6 pt-5 text-primary-foreground">
        <div className="mx-auto max-w-3xl px-4">
          <h1 className="sr-only">NTRS.MART — Shop · Click · Deliver</h1>
          <img src={brandImage.url} alt="NTRS.MART — Shop, Click, Deliver. Quality Products, Best Prices, At Your Doorstep" className="mx-auto block max-h-64 w-full object-contain sm:max-h-80" />
          <div className="text-center"><Button variant="secondary" className="mt-2 h-12 px-7 font-bold" onClick={() => document.getElementById("catalogue")?.scrollIntoView({ behavior: "smooth" })}>SHOP NOW</Button></div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-[11px] font-semibold">
            {[
              { icon: Truck, label: "Same-day Kampala" },
              { icon: Wallet, label: "Cash on delivery" },
              { icon: BadgeCheck, label: "Verified sellers" },
            ].map(({ icon: Icon, label }) => (
              <div
                key={label}
                className="flex flex-col items-center gap-1 rounded-xl bg-primary-foreground/10 px-2 py-3 text-center"
              >
                <Icon className="size-4 text-accent" />
                {label}
              </div>
            ))}
          </div>
        </div>
      </section>

      {promotions.length > 0 && <section aria-label="Promotions" className="mx-auto max-w-3xl px-4 py-5">
        {(() => { const p = promotions[promotionIndex % promotions.length]; if (!p) return null; return <div className="grid min-h-36 grid-cols-[minmax(0,1fr)_auto] items-center gap-3 overflow-hidden rounded-lg bg-secondary p-4">
          <div className="min-w-0"><p className="text-xs font-bold uppercase text-primary">{p.promotional_text}</p><h2 className="mt-1 font-display text-xl font-bold">{p.headline}</h2><p className="mt-1 text-sm text-muted-foreground">{p.description}</p><Button variant="link" className="mt-2 px-0" onClick={() => document.getElementById("catalogue")?.scrollIntoView({ behavior: "smooth" })}>Shop now →</Button></div>
          {p.image_url && <img src={p.image_url} alt="" className="size-24 rounded object-cover sm:size-36" />}
        </div>; })()}
        {promotions.length > 1 && <div className="mt-2 flex justify-center gap-4"><Button variant="outline" size="sm" onClick={() => setPromotionIndex(i => (i - 1 + promotions.length) % promotions.length)} aria-label="Previous promotion">←</Button><span className="self-center text-xs">{promotionIndex % promotions.length + 1} / {promotions.length}</span><Button variant="outline" size="sm" onClick={() => setPromotionIndex(i => i + 1)} aria-label="Next promotion">→</Button></div>}
      </section>}

      <div className="sticky top-[132px] z-20 bg-background/95 py-3 backdrop-blur">
        <div className="mx-auto max-w-3xl overflow-x-auto px-4 no-scrollbar">
          <div className="flex gap-2">
            {categories.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCategory(c)}
                className={cn(
                  "shrink-0 rounded-full border px-3.5 py-1.5 text-sm font-semibold transition",
                  category === c
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-muted-foreground",
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      <main id="catalogue" className="mx-auto max-w-3xl scroll-mt-52 px-4">
        {filtered.length === 0 ? (
          <p className="py-16 text-center text-sm text-muted-foreground">
            No products match “{query}”.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </main>
      <WhatsAppFab />
    </div>
  );
}

import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const TEN_YEARS = 60 * 60 * 24 * 365 * 10;

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", context.userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

const productInput = z.object({
  id: z.string().uuid().optional(),
  name: z.string().trim().min(2).max(160),
  description: z.string().trim().max(1000).optional().or(z.literal("")),
  price: z.number().min(0).max(100_000_000),
  category: z.string().trim().max(80).optional().or(z.literal("")),
  stock: z.number().int().min(0).max(1_000_000),
  is_active: z.boolean(),
  image_url: z.string().trim().max(2000).optional().or(z.literal("")),
  images: z.array(z.string().url()).max(12).default([]),
  sale_price: z.number().min(0).nullable(),
  discount_active: z.boolean(),
});

export const saveProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => productInput.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const row = {
      name: data.name,
      description: data.description || null,
      price: data.price,
      category: data.category || null,
      stock: data.stock,
      is_active: data.is_active,
      image_url: data.image_url || null,
      images: data.images,
      sale_price: data.sale_price,
      discount_active: data.discount_active,
    };
    const query = data.id
      ? context.supabase.from("products").update(row).eq("id", data.id)
      : context.supabase.from("products").insert(row);
    const { error } = await query;
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { error } = await context.supabase.from("products").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const uploadProductImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        file_name: z.string().trim().min(1).max(200),
        content_type: z.string().trim().min(3).max(100),
        // base64 payload, ~10MB max raw
        base64: z.string().min(10).max(14_000_000),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    if (!data.content_type.startsWith("image/")) throw new Error("Only image files are allowed.");

    const bytes = Uint8Array.from(atob(data.base64), (c) => c.charCodeAt(0));
    const ext = (data.file_name.split(".").pop() ?? "jpg").toLowerCase().slice(0, 5);
    const path = `products/${crypto.randomUUID()}.${ext}`;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: uploadError } = await supabaseAdmin.storage
      .from("product-images")
      .upload(path, bytes, { contentType: data.content_type, upsert: false });
    if (uploadError) throw new Error(uploadError.message);

    const { data: signed, error: signError } = await supabaseAdmin.storage
      .from("product-images")
      .createSignedUrl(path, TEN_YEARS);
    if (signError || !signed) throw new Error(signError?.message ?? "Could not sign image URL.");

    return { image_url: signed.signedUrl, path };
  });

export const listOrders = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("orders")
      .select(
        "id, order_number, customer_name, customer_phone, zone_name, address, landmark, notes, subtotal, delivery_fee, total, payment_method, payment_status, status, archived_at, created_at, order_items(id, product_name, variant_name, unit_price, quantity)",
      )
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const updateOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(["pending", "confirmed", "preparing", "out for delivery", "delivering", "delivered", "cancelled"]),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { error } = await context.supabase
      .from("orders")
      .update({ status: data.status })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
    if (error) throw new Error(error.message);
    const { data: roles, error: rolesError } = await supabaseAdmin
      .from("user_roles")
      .select("user_id, role");
    if (rolesError) throw new Error(rolesError.message);
    const adminIds = new Set((roles ?? []).filter((r) => r.role === "admin").map((r) => r.user_id));
    return (data.users ?? []).map((u) => ({
      id: u.id,
      email: u.email ?? "",
      created_at: u.created_at,
      confirmed: Boolean(u.email_confirmed_at),
      is_admin: adminIds.has(u.id),
    }));
  });

export const setUserAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ user_id: z.string().uuid(), is_admin: z.boolean() }).parse(data),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    if (data.user_id === context.userId && !data.is_admin) {
      throw new Error("You cannot remove your own admin access.");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (data.is_admin) {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: data.user_id, role: "admin" }, { onConflict: "user_id,role" });
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .delete()
        .eq("user_id", data.user_id)
        .eq("role", "admin");
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const archiveOrder = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid(), archived: z.boolean() }).parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const query = context.supabase.from("orders").update({ archived_at: data.archived ? new Date().toISOString() : null }).eq("id", data.id);
    if (data.archived) query.eq("status", "delivered");
    const { data: updated, error } = await query.select("id").maybeSingle();
    if (error) throw new Error(error.message);
    if (!updated) throw new Error("Only delivered orders can be archived.");
    return { ok: true };
  });

const variantInput = z.object({ id: z.string().uuid().optional(), product_id: z.string().uuid(), name: z.string().trim().min(1).max(80), images: z.array(z.string().url()).max(12), sort_order: z.number().int() });
export const saveVariant = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => variantInput.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const row = { product_id: data.product_id, name: data.name, images: data.images, sort_order: data.sort_order };
    const { error } = await (data.id ? context.supabase.from("product_variants").update(row).eq("id", data.id) : context.supabase.from("product_variants").insert(row));
    if (error) throw new Error(error.message); return { ok: true };
  });
export const deleteVariant = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => { await assertAdmin(context); const { error } = await context.supabase.from("product_variants").delete().eq("id", data.id); if (error) throw new Error(error.message); return { ok: true }; });

const promotionInput = z.object({ id: z.string().uuid().optional(), headline: z.string().trim().min(1).max(120), description: z.string().max(500), promotional_text: z.string().max(120), image_url: z.string().url().nullable(), starts_at: z.string().nullable(), ends_at: z.string().nullable(), sort_order: z.number().int(), is_active: z.boolean() });
export const listPromotions = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => { await assertAdmin(context); const { data, error } = await context.supabase.from("homepage_promotions").select("*").order("sort_order"); if (error) throw new Error(error.message); return data ?? []; });
export const savePromotion = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => promotionInput.parse(data))
  .handler(async ({ data, context }) => { await assertAdmin(context); const { id, ...row } = data; const { error } = await (id ? context.supabase.from("homepage_promotions").update(row).eq("id", id) : context.supabase.from("homepage_promotions").insert(row)); if (error) throw new Error(error.message); return { ok: true }; });
export const deletePromotion = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => { await assertAdmin(context); const { error } = await context.supabase.from("homepage_promotions").delete().eq("id", data.id); if (error) throw new Error(error.message); return { ok: true }; });

const welcomeButtonUrl = z.string().trim().max(500).refine(
  (value) => value === "" || value.startsWith("/") || value.startsWith("#") || /^https:\/\//i.test(value),
  "Use a page path, catalogue anchor, or secure HTTPS link.",
);
const welcomeSlideInput = z.object({ id: z.string().uuid().optional(), headline: z.string().trim().min(1).max(120), description: z.string().trim().max(500), image_url: z.string().url().nullable(), button_label: z.string().trim().max(40).nullable(), button_url: welcomeButtonUrl.nullable(), sort_order: z.number().int(), is_active: z.boolean() });
export const listWelcomeSlides = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => { await assertAdmin(context); const { data, error } = await context.supabase.from("welcome_slides").select("*").order("sort_order"); if (error) throw new Error(error.message); return data ?? []; });
export const saveWelcomeSlide = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => welcomeSlideInput.parse(data))
  .handler(async ({ data, context }) => { await assertAdmin(context); const { id, ...row } = data; const { error } = await (id ? context.supabase.from("welcome_slides").update(row).eq("id", id) : context.supabase.from("welcome_slides").insert(row)); if (error) throw new Error(error.message); return { ok: true }; });
export const deleteWelcomeSlide = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => { await assertAdmin(context); const { error } = await context.supabase.from("welcome_slides").delete().eq("id", data.id); if (error) throw new Error(error.message); return { ok: true }; });

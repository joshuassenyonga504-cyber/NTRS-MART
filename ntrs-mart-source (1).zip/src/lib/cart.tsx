import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
export type CartItem = { id: string; name: string; price: number; image_url: string | null; quantity: number; variant_id?: string | null; variant_name?: string | null };
type CartContextValue = { items: CartItem[]; count: number; subtotal: number; add: (item: Omit<CartItem, "quantity">, quantity?: number) => void; setQuantity: (key: string, quantity: number) => void; remove: (key: string) => void; clear: () => void };
export const cartKey = (item: Pick<CartItem, "id" | "variant_id">) => `${item.id}:${item.variant_id ?? ""}`;
const STORAGE_KEY = "ntrsmart.cart.v1";
const CartContext = createContext<CartContextValue | null>(null);
export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => { try { const raw = window.localStorage.getItem(STORAGE_KEY); if (raw) setItems(JSON.parse(raw) as CartItem[]); } catch { /* ignore malformed cart */ } setLoaded(true); }, []);
  useEffect(() => { if (loaded) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); }, [items, loaded]);
  const add = useCallback((item: Omit<CartItem, "quantity">, quantity = 1) => setItems(prev => {
    const key = cartKey(item);
    return prev.some(i => cartKey(i) === key) ? prev.map(i => cartKey(i) === key ? { ...i, quantity: i.quantity + quantity, price: item.price } : i) : [...prev, { ...item, quantity }];
  }), []);
  const setQuantity = useCallback((key: string, quantity: number) => setItems(prev => quantity <= 0 ? prev.filter(i => cartKey(i) !== key) : prev.map(i => cartKey(i) === key ? { ...i, quantity } : i)), []);
  const remove = useCallback((key: string) => setItems(prev => prev.filter(i => cartKey(i) !== key)), []);
  const clear = useCallback(() => setItems([]), []);
  const value = useMemo<CartContextValue>(() => ({ items, count: items.reduce((s,i) => s + i.quantity, 0), subtotal: items.reduce((s,i) => s + i.price * i.quantity, 0), add, setQuantity, remove, clear }), [items, add, setQuantity, remove, clear]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
export function useCart() { const ctx = useContext(CartContext); if (!ctx) throw new Error("useCart must be used inside CartProvider"); return ctx; }

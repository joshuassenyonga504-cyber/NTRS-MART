INSERT INTO public.user_roles (user_id, role)
VALUES ('a80bc632-9b8b-44c0-b94e-17c78751323b', 'admin')
ON CONFLICT (user_id, role) DO NOTHING;
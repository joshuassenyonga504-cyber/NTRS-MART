import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import {
  ArrowLeft,
  ChevronDown,
  ImagePlus,
  Loader2,
  LogOut,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { allProductsQuery, variantsQuery, discountPercent, type Product } from "@/lib/store-data";
import {
  deleteProduct,
  listOrders,
  listUsers,
  saveProduct,
  setUserAdmin,
  updateOrderStatus,
  uploadProductImage,
  saveVariant, deleteVariant, listPromotions, savePromotion, deletePromotion, archiveOrder,
  listWelcomeSlides, saveWelcomeSlide, deleteWelcomeSlide,
} from "@/lib/admin.functions";
import { formatUGX } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin dashboard — NTRS.MART" },
      { name: "description", content: "Manage NTRS.MART products, images and customer orders." },
      { property: "og:title", content: "Admin dashboard — NTRS.MART" },
      { property: "og:description", content: "NTRS.MART store management." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminPage,
});

type Draft = {
  id?: string;
  name: string;
  description: string;
  price: string;
  category: string;
  stock: string;
  is_active: boolean;
  image_url: string;
  images: string[];
  sale_price: string;
  discount_active: boolean;
};

const emptyDraft: Draft = {
  name: "",
  description: "",
  price: "",
  category: "",
  stock: "0",
  is_active: true,
  image_url: "",
  images: [],
  sale_price: "",
  discount_active: false,
};

function AdminPage() {
  const { isAdmin, loading, user } = useAuth();
  const [tab, setTab] = useState<"products" | "orders" | "archived" | "promotions" | "welcome" | "users">("products");

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="grid min-h-screen place-items-center px-6 text-center">
        <div className="max-w-sm">
          <h1 className="font-display text-xl font-bold">Admin access required</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            You&apos;re signed in as {user?.email}, but this account doesn&apos;t have the admin
            role yet.
          </p>
          <Button asChild className="mt-5 h-12 w-full rounded-xl">
            <Link to="/">Back to shop</Link>
          </Button>
          <button
            type="button"
            onClick={() => void supabase.auth.signOut()}
            className="mt-3 w-full text-xs text-muted-foreground underline"
          >
            Sign out
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-16">
      <header className="sticky top-0 z-30 bg-primary px-4 py-4 text-primary-foreground shadow-lg">
        <div className="mx-auto flex max-w-3xl items-center gap-3">
          <Link to="/" aria-label="Back to shop">
            <ArrowLeft className="size-5" />
          </Link>
          <h1 className="font-display text-lg font-bold">Admin dashboard</h1>
          <button
            type="button"
            aria-label="Sign out"
            onClick={() => void supabase.auth.signOut()}
            className="ml-auto grid size-9 place-items-center rounded-xl bg-primary-foreground/10"
          >
            <LogOut className="size-4" />
          </button>
        </div>
        <div className="mx-auto mt-3 flex max-w-3xl gap-2 overflow-x-auto pb-1 no-scrollbar">
          {(["products", "orders", "archived", "promotions", "welcome", "users"] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={cn(
                "rounded-full px-3.5 py-1.5 text-sm font-semibold capitalize",
                tab === t
                  ? "bg-accent text-accent-foreground"
                  : "bg-primary-foreground/10 text-primary-foreground",
              )}
            >
              {t === "welcome" ? "Welcome Carousel" : t}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 pt-4">
        {tab === "products" ? <ProductsTab /> : tab === "orders" ? <OrdersTab /> : tab === "archived" ? <OrdersTab archived /> : tab === "promotions" ? <PromotionsTab /> : tab === "welcome" ? <WelcomeSlidesTab /> : <UsersTab />}
      </main>
    </div>
  );
}

function ProductsTab() {
  const queryClient = useQueryClient();
  const { data: products = [], isLoading } = useQuery(allProductsQuery);
  const save = useServerFn(saveProduct);
  const remove = useServerFn(deleteProduct);
  const upload = useServerFn(uploadProductImage);

  const [draft, setDraft] = useState<Draft | null>(null);
  const [uploading, setUploading] = useState(false);

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["products"] });
  };

  const saveMutation = useMutation({
    mutationFn: async (d: Draft) =>
      save({
        data: {
          ...(d.id ? { id: d.id } : {}),
          name: d.name.trim(),
          description: d.description.trim(),
          price: Number(d.price),
          category: d.category.trim(),
          stock: Number(d.stock),
          is_active: d.is_active,
          image_url: d.image_url.trim(),
          images: d.images,
          sale_price: d.sale_price === "" ? null : Number(d.sale_price),
          discount_active: d.discount_active,
        },
      }),
    onSuccess: () => {
      toast.success("Product saved");
      setDraft(null);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => remove({ data: { id } }),
    onSuccess: () => {
      toast.success("Product deleted");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const handleFile = async (file: File, onUploaded?: (url: string) => void) => {
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Image must be under 10MB.");
      return;
    }
    setUploading(true);
    try {
      const buffer = await file.arrayBuffer();
      let binary = "";
      const bytes = new Uint8Array(buffer);
      for (let i = 0; i < bytes.length; i += 8192) {
        binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
      }
      const result = await upload({
        data: {
          file_name: file.name,
          content_type: file.type || "image/jpeg",
          base64: btoa(binary),
        },
      });
      if (onUploaded) onUploaded(result.image_url);
      else setDraft((d) => (d ? { ...d, image_url: result.image_url } : d));
      toast.success("Image uploaded");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const startEdit = (p: Product) =>
    setDraft({
      id: p.id,
      name: p.name,
      description: p.description ?? "",
      price: String(p.price),
      category: p.category ?? "",
      stock: String(p.stock),
      is_active: p.is_active,
      image_url: p.image_url ?? "",
      images: p.images ?? [],
      sale_price: p.sale_price === null ? "" : String(p.sale_price),
      discount_active: p.discount_active,
    });

  return (
    <div className="space-y-4">
      {!draft && (
        <Button
          onClick={() => setDraft({ ...emptyDraft })}
          className="h-12 w-full rounded-xl font-bold"
        >
          <Plus className="size-5" /> Add product
        </Button>
      )}

      {draft && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (draft.name.trim().length < 2) {
              toast.error("Enter a product name.");
              return;
            }
            if (!Number.isFinite(Number(draft.price)) || Number(draft.price) < 0) {
              toast.error("Enter a valid price.");
              return;
            }
            if (draft.discount_active && (draft.sale_price === "" || Number(draft.sale_price) >= Number(draft.price) || Number(draft.sale_price) < 0)) { toast.error("Sale price must be lower than the regular price."); return; }
            saveMutation.mutate(draft);
          }}
          className="space-y-3 rounded-2xl bg-card p-4 shadow-card"
        >
          <h2 className="font-display text-base font-bold">
            {draft.id ? "Edit product" : "New product"}
          </h2>

          <div className="flex items-center gap-3">
            <div className="size-20 shrink-0 overflow-hidden rounded-xl bg-muted">
              {draft.image_url ? (
                <img src={draft.image_url} alt="" className="size-full object-cover" />
              ) : (
                <div className="grid size-full place-items-center text-[10px] text-muted-foreground">
                  No image
                </div>
              )}
            </div>
            <label className="inline-flex h-11 cursor-pointer items-center gap-2 rounded-xl border border-border px-3 text-sm font-semibold">
              {uploading ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <ImagePlus className="size-4" />
              )}
              {draft.image_url ? "Change image" : "Upload image"}
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void handleFile(file);
                  e.target.value = "";
                }}
              />
            </label>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="p-name">Name</Label>
            <Input
              id="p-name"
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              className="h-12 rounded-xl"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="p-price">Price (UGX)</Label>
              <Input
                id="p-price"
                inputMode="numeric"
                value={draft.price}
                onChange={(e) => setDraft({ ...draft, price: e.target.value })}
                className="h-12 rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="p-stock">Stock</Label>
              <Input
                id="p-stock"
                inputMode="numeric"
                value={draft.stock}
                onChange={(e) => setDraft({ ...draft, stock: e.target.value })}
                className="h-12 rounded-xl"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3"><div><Label htmlFor="p-sale">Sale price (UGX)</Label><Input id="p-sale" inputMode="numeric" value={draft.sale_price} onChange={e => setDraft({ ...draft, sale_price: e.target.value })} placeholder="Optional" /></div><label className="flex items-center gap-2 self-end pb-3 text-sm"><input type="checkbox" checked={draft.discount_active} onChange={e => setDraft({ ...draft, discount_active: e.target.checked })} />Discount active</label></div>
          {draft.discount_active && draft.sale_price && Number(draft.price) > Number(draft.sale_price) && <p className="text-sm font-bold text-primary">{Math.round((1 - Number(draft.sale_price) / Number(draft.price)) * 100)}% OFF</p>}
          <div className="space-y-1.5">
            <Label htmlFor="p-cat">Category</Label>
            <Input
              id="p-cat"
              value={draft.category}
              onChange={(e) => setDraft({ ...draft, category: e.target.value })}
              className="h-12 rounded-xl"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="p-desc">Description</Label>
            <Textarea
              id="p-desc"
              rows={3}
              value={draft.description}
              onChange={(e) => setDraft({ ...draft, description: e.target.value })}
              className="rounded-xl"
            />
          </div>
          <div className="space-y-2"><Label>Additional images</Label><div className="flex flex-wrap gap-2">{draft.images.map((url, i) => <div key={i} className="relative"><img src={url} alt={`Additional image ${i + 1}`} className="size-16 rounded object-cover" /><Button type="button" size="icon" variant="destructive" className="absolute -right-1 -top-1 size-6" onClick={() => setDraft(d => d ? { ...d, images: d.images.filter((_, n) => n !== i) } : d)}>×</Button></div>)}</div><label className="inline-flex h-11 cursor-pointer items-center gap-2 rounded border border-border px-3 text-sm"><ImagePlus className="size-4" />Add images<input type="file" accept="image/*" multiple className="hidden" onChange={e => { for (const file of Array.from(e.target.files ?? [])) void handleFile(file, url => setDraft(d => d ? { ...d, images: [...d.images, url] } : d)); e.target.value = ""; }} /></label></div>
          {draft.id && <VariantsEditor productId={draft.id} upload={upload} />}
          <label className="flex items-center gap-2 text-sm font-semibold">
            <input
              type="checkbox"
              checked={draft.is_active}
              onChange={(e) => setDraft({ ...draft, is_active: e.target.checked })}
              className="size-4"
            />
            Visible in the shop
          </label>

          <div className="flex gap-2">
            <Button
              type="submit"
              disabled={saveMutation.isPending}
              className="h-12 flex-1 rounded-xl font-bold"
            >
              {saveMutation.isPending ? <Loader2 className="size-4 animate-spin" /> : null}
              Save
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setDraft(null)}
              className="h-12 rounded-xl"
            >
              Cancel
            </Button>
          </div>
        </form>
      )}

      {isLoading ? (
        <Loader2 className="mx-auto size-5 animate-spin text-muted-foreground" />
      ) : (
        <ul className="space-y-2">
          {products.map((p) => (
            <li key={p.id} className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-card">
              <div className="size-14 shrink-0 overflow-hidden rounded-xl bg-muted">
                {p.image_url && (
                  <img src={p.image_url} alt="" loading="lazy" className="size-full object-cover" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{p.name}</p>
                <p className="text-xs text-muted-foreground">
                  {formatUGX(p.price)} · stock {p.stock}
                  {!p.is_active && " · hidden"}
                </p>
              </div>
              <button
                type="button"
                aria-label={`Edit ${p.name}`}
                onClick={() => startEdit(p)}
                className="grid size-9 place-items-center rounded-lg border border-border"
              >
                <Pencil className="size-4" />
              </button>
              <button
                type="button"
                aria-label={`Delete ${p.name}`}
                onClick={() => {
                  if (window.confirm(`Delete ${p.name}?`)) deleteMutation.mutate(p.id);
                }}
                className="grid size-9 place-items-center rounded-lg border border-border text-destructive"
              >
                <Trash2 className="size-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

const STATUSES = ["pending", "confirmed", "preparing", "out for delivery", "delivered", "cancelled"] as const;

function OrdersTab({ archived = false }: { archived?: boolean }) {
  const queryClient = useQueryClient();
  const fetchOrders = useServerFn(listOrders);
  const setStatus = useServerFn(updateOrderStatus);
  const setArchived = useServerFn(archiveOrder);
  const [expanded, setExpanded] = useState<string | null>(null);


  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["admin-orders"],
    queryFn: () => fetchOrders(),
  });

  const statusMutation = useMutation({
    mutationFn: async (vars: { id: string; status: (typeof STATUSES)[number] }) =>
      setStatus({ data: vars }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["admin-orders"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) {
    return <Loader2 className="mx-auto size-5 animate-spin text-muted-foreground" />;
  }

  const visibleOrders = orders.filter(o => Boolean(o.archived_at) === archived);
  if (visibleOrders.length === 0) {
    return <p className="py-12 text-center text-sm text-muted-foreground">{archived ? "No archived orders yet." : "No orders yet."}</p>;
  }

  return (
    <ul className="space-y-3">
      {visibleOrders.map((o) => {
        const items = o.order_items ?? [];
        const itemCount = items.reduce((sum, i) => sum + Number(i.quantity), 0);
        const open = expanded === o.id;
        return (
        <li key={o.id} className="space-y-2 rounded-2xl bg-card p-4 shadow-card">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
            <div className="min-w-0">
              <p className="font-display text-sm font-bold">{o.order_number}</p>
              <p className="truncate text-xs text-muted-foreground">
                {o.customer_name} · {o.customer_phone}
              </p>
            </div>
            <span className="shrink-0 font-display text-sm font-bold text-primary">
              {formatUGX(Number(o.total))}
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            {new Date(o.created_at).toLocaleString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
          <p className="text-xs text-muted-foreground">
            {o.zone_name} — {o.address}
            {o.landmark ? ` (near ${o.landmark})` : ""}
          </p>
          <p className="text-xs font-semibold">
            {o.payment_method === "card" ? "Card" : "Cash on delivery"} · {o.payment_status} ·{" "}
            <span className="capitalize">{o.status}</span>
          </p>

          <button
            type="button"
            onClick={() => setExpanded(open ? null : o.id)}
            aria-expanded={open}
            className="flex w-full items-center justify-between gap-2 rounded-xl border border-border px-3 py-2.5 text-left text-xs font-bold"
          >
            <span>
              {open ? "Hide items" : "View items"} ({itemCount} {itemCount === 1 ? "item" : "items"})
            </span>
            <ChevronDown className={cn("size-4 shrink-0 transition-transform", open && "rotate-180")} />
          </button>

          {open ? (
            <div className="space-y-2 rounded-xl bg-secondary/60 p-3">
              {items.length === 0 ? (
                <p className="text-xs text-muted-foreground">No items recorded for this order.</p>
              ) : (
                <ul className="space-y-2">
                  {items.map((i) => (
                    <li
                      key={i.id}
                      className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2 text-xs"
                    >
                      <div className="min-w-0">
                        <p className="font-semibold">{i.product_name}</p>
                        <p className="text-muted-foreground">
                          {i.variant_name && <span className="block">Colour: {i.variant_name}</span>}
                          {i.quantity} × {formatUGX(Number(i.unit_price))}
                        </p>
                      </div>
                      <span className="shrink-0 font-bold">
                        {formatUGX(Number(i.unit_price) * Number(i.quantity))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
              <div className="space-y-1 border-t border-border pt-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Items subtotal</span>
                  <span className="font-semibold">{formatUGX(Number(o.subtotal))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Delivery</span>
                  <span className="font-semibold">{formatUGX(Number(o.delivery_fee))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-bold">Total</span>
                  <span className="font-display font-extrabold text-primary">
                    {formatUGX(Number(o.total))}
                  </span>
                </div>
              </div>
              {o.notes ? (
                <p className="text-xs text-muted-foreground">Notes: {o.notes}</p>
              ) : null}
            </div>
          ) : null}

          {!archived && <div className="flex flex-wrap gap-1.5">
            {STATUSES.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => statusMutation.mutate({ id: o.id, status: s })}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[11px] font-semibold capitalize",
                  o.status === s ? "border-primary bg-primary text-primary-foreground" : "border-border",
                )}
              >
                {s}
              </button>
            ))}
          </div>}
          {(archived || o.status === "delivered") && <Button variant="outline" className="h-10 w-full" onClick={async () => { try { await setArchived({ data: { id: o.id, archived: !archived } }); void queryClient.invalidateQueries({ queryKey: ["admin-orders"] }); toast.success(archived ? "Order restored" : "Order archived"); } catch (e) { toast.error(e instanceof Error ? e.message : "Could not update order"); } }}>{archived ? "Restore order" : "Archive order"}</Button>}
        </li>
        );
      })}
    </ul>
  );
}

function UsersTab() {
  const queryClient = useQueryClient();
  const fetchUsers = useServerFn(listUsers);
  const setAdmin = useServerFn(setUserAdmin);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => fetchUsers(),
  });

  const roleMutation = useMutation({
    mutationFn: async (vars: { user_id: string; is_admin: boolean }) => setAdmin({ data: vars }),
    onSuccess: () => {
      toast.success("Access updated");
      void queryClient.invalidateQueries({ queryKey: ["admin-users"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) {
    return <Loader2 className="mx-auto size-5 animate-spin text-muted-foreground" />;
  }

  return (
    <ul className="space-y-2">
      {users.map((u) => (
        <li key={u.id} className="flex items-center gap-3 rounded-2xl bg-card p-4 shadow-card">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{u.email}</p>
            <p className="text-xs text-muted-foreground">
              {u.is_admin ? "Administrator" : "Customer"}
              {!u.confirmed && " · email not confirmed"}
            </p>
          </div>
          <Button
            variant={u.is_admin ? "outline" : "default"}
            disabled={roleMutation.isPending}
            onClick={() => roleMutation.mutate({ user_id: u.id, is_admin: !u.is_admin })}
            className="h-10 shrink-0 rounded-xl text-xs font-bold"
          >
            {u.is_admin ? "Remove admin" : "Make admin"}
          </Button>
        </li>
      ))}
    </ul>
  );
}

type Uploaded = typeof uploadProductImage;
function VariantsEditor({ productId, upload }: { productId: string; upload: ReturnType<typeof useServerFn<Uploaded>> }) {
  const queryClient = useQueryClient();
  const { data: variants = [] } = useQuery(variantsQuery(productId));
  const save = useServerFn(saveVariant); const remove = useServerFn(deleteVariant);
  const [editing, setEditing] = useState<{ id?: string; name: string; images: string[]; sort_order: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const refresh = () => void queryClient.invalidateQueries({ queryKey: ["variants", productId] });
  const uploadFiles = async (files: FileList) => {
    setBusy(true);
    try { for (const file of Array.from(files)) {
      if (file.size > 10 * 1024 * 1024) throw new Error("Image must be under 10MB.");
      const bytes = new Uint8Array(await file.arrayBuffer()); let binary = "";
      for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
      const result = await upload({ data: { file_name: file.name, content_type: file.type || "image/jpeg", base64: btoa(binary) } });
      setEditing(prev => prev ? { ...prev, images: [...prev.images, result.image_url] } : prev);
    }} catch (e) { toast.error(e instanceof Error ? e.message : "Upload failed"); } finally { setBusy(false); }
  };
  return <div className="space-y-2 border-t border-border pt-3"><div className="flex items-center justify-between"><Label>Colours / variants</Label><Button type="button" variant="outline" size="sm" onClick={() => setEditing({ name: "", images: [], sort_order: variants.length })}>Add colour</Button></div>
    {variants.map(v => <div key={v.id} className="flex items-center gap-2 text-sm">{v.images[0] && <img src={v.images[0]} alt="" className="size-9 rounded object-cover" />}<span className="flex-1">{v.name} · {v.images.length} photos</span><Button type="button" size="sm" variant="outline" onClick={() => setEditing({ id: v.id, name: v.name, images: v.images, sort_order: v.sort_order })}>Edit</Button><Button type="button" size="icon" variant="ghost" aria-label={`Delete ${v.name}`} onClick={async () => { if (!window.confirm(`Delete ${v.name}?`)) return; try { await remove({ data: { id: v.id } }); refresh(); } catch (e) { toast.error(String(e)); } }}><Trash2 className="size-4" /></Button></div>)}
    {editing && <div className="space-y-2 rounded border border-border p-3"><Input placeholder="Colour name, e.g. Brown" value={editing.name} onChange={e => setEditing({ ...editing, name: e.target.value })} /><Input type="number" aria-label="Variant display order" value={editing.sort_order} onChange={e => setEditing({ ...editing, sort_order: Number(e.target.value) })} /><div className="flex flex-wrap gap-2">{editing.images.map((url, i) => <div key={i} className="relative"><img src={url} alt="" className="size-16 rounded object-cover" /><Button type="button" size="icon" variant="destructive" className="absolute -right-1 -top-1 size-6" onClick={() => setEditing(d => d ? { ...d, images: d.images.filter((_, n) => n !== i) } : d)}>×</Button></div>)}</div><label className="inline-flex h-11 cursor-pointer items-center gap-2 rounded border border-border px-3 text-sm"><ImagePlus className="size-4" />{busy ? "Uploading…" : "Add photos"}<input type="file" multiple accept="image/*" className="hidden" onChange={e => { if (e.target.files) void uploadFiles(e.target.files); e.target.value = ""; }} /></label><div className="flex gap-2"><Button type="button" disabled={busy || !editing.name.trim()} onClick={async () => { try { await save({ data: { ...editing, product_id: productId } }); setEditing(null); refresh(); } catch (e) { toast.error(String(e)); } }}>Save colour</Button><Button type="button" variant="outline" onClick={() => setEditing(null)}>Cancel</Button></div></div>}
  </div>;
}

type PromotionDraft = { id?: string; headline: string; description: string; promotional_text: string; image_url: string | null; starts_at: string; ends_at: string; sort_order: number; is_active: boolean };
function PromotionsTab() {
  const queryClient = useQueryClient(); const fetchAll = useServerFn(listPromotions); const save = useServerFn(savePromotion); const remove = useServerFn(deletePromotion); const upload = useServerFn(uploadProductImage);
  const { data: promotions = [] } = useQuery({ queryKey: ["admin-promotions"], queryFn: () => fetchAll() });
  const [draft, setDraft] = useState<PromotionDraft | null>(null); const [busy, setBusy] = useState(false);
  const refresh = () => { void queryClient.invalidateQueries({ queryKey: ["admin-promotions"] }); void queryClient.invalidateQueries({ queryKey: ["promotions"] }); };
  return <div className="space-y-3"><Button className="h-12 w-full" onClick={() => setDraft({ headline: "", description: "", promotional_text: "", image_url: null, starts_at: "", ends_at: "", sort_order: promotions.length, is_active: false })}><Plus className="size-4" /> Add promotion</Button>
    {draft && <form className="space-y-3 rounded-lg bg-card p-4 shadow-card" onSubmit={async e => { e.preventDefault(); if (draft.starts_at && draft.ends_at && draft.starts_at > draft.ends_at) { toast.error("End date must follow start date"); return; } setBusy(true); try { await save({ data: { ...draft, starts_at: draft.starts_at ? new Date(draft.starts_at).toISOString() : null, ends_at: draft.ends_at ? new Date(draft.ends_at).toISOString() : null } }); setDraft(null); refresh(); toast.success("Promotion saved"); } catch (err) { toast.error(String(err)); } finally { setBusy(false); } }}>
      <h2 className="font-bold">{draft.id ? "Edit promotion" : "New promotion"}</h2><Label>Headline<Input required value={draft.headline} onChange={e => setDraft({ ...draft, headline: e.target.value })} /></Label><Label>Description<Textarea value={draft.description} onChange={e => setDraft({ ...draft, description: e.target.value })} /></Label><Label>Promotional text<Input value={draft.promotional_text} onChange={e => setDraft({ ...draft, promotional_text: e.target.value })} /></Label>
      {draft.image_url && <img src={draft.image_url} alt="Promotion preview" className="h-28 w-full object-contain" />}<label className="inline-flex h-11 cursor-pointer items-center gap-2 rounded border border-border px-3 text-sm"><ImagePlus className="size-4" />Upload/change image<input className="hidden" type="file" accept="image/*" onChange={async e => { const file = e.target.files?.[0]; if (!file) return; setBusy(true); try { const bytes = new Uint8Array(await file.arrayBuffer()); let binary = ""; for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192)); const result = await upload({ data: { file_name: file.name, content_type: file.type || "image/jpeg", base64: btoa(binary) } }); setDraft(d => d ? { ...d, image_url: result.image_url } : d); } catch (err) { toast.error(String(err)); } finally { setBusy(false); } }} /></label>
      <div className="grid grid-cols-2 gap-2"><Label>Start (optional)<Input type="datetime-local" value={draft.starts_at} onChange={e => setDraft({ ...draft, starts_at: e.target.value })} /></Label><Label>End (optional)<Input type="datetime-local" value={draft.ends_at} onChange={e => setDraft({ ...draft, ends_at: e.target.value })} /></Label></div><Label>Display order<Input type="number" value={draft.sort_order} onChange={e => setDraft({ ...draft, sort_order: Number(e.target.value) })} /></Label><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={draft.is_active} onChange={e => setDraft({ ...draft, is_active: e.target.checked })} />Active</label><div className="flex gap-2"><Button disabled={busy} type="submit">Save</Button><Button type="button" variant="outline" onClick={() => setDraft(null)}>Cancel</Button></div>
    </form>}
    {promotions.map(p => <div key={p.id} className="flex items-center gap-3 rounded-lg bg-card p-3 shadow-card">{p.image_url && <img src={p.image_url} alt="" className="size-14 rounded object-cover" />}<div className="min-w-0 flex-1"><p className="truncate font-semibold">{p.headline}</p><p className="text-xs text-muted-foreground">{p.is_active ? "Active" : "Inactive"} · order {p.sort_order}</p></div><Button size="icon" variant="outline" aria-label={`Edit ${p.headline}`} onClick={() => setDraft({ ...p, starts_at: p.starts_at?.slice(0, 16) ?? "", ends_at: p.ends_at?.slice(0, 16) ?? "" })}><Pencil className="size-4" /></Button><Button size="icon" variant="outline" aria-label={`Delete ${p.headline}`} onClick={async () => { if (!window.confirm(`Delete ${p.headline}?`)) return; try { await remove({ data: { id: p.id } }); refresh(); } catch (e) { toast.error(String(e)); } }}><Trash2 className="size-4" /></Button></div>)}
  </div>;
}

type WelcomeDraft = { id?: string; headline: string; description: string; image_url: string | null; button_label: string; button_url: string; sort_order: number; is_active: boolean };
function WelcomeSlidesTab() {
  const queryClient = useQueryClient();
  const fetchAll = useServerFn(listWelcomeSlides); const save = useServerFn(saveWelcomeSlide); const remove = useServerFn(deleteWelcomeSlide); const upload = useServerFn(uploadProductImage);
  const { data: slides = [], isLoading } = useQuery({ queryKey: ["admin-welcome-slides"], queryFn: () => fetchAll() });
  const [draft, setDraft] = useState<WelcomeDraft | null>(null); const [busy, setBusy] = useState(false);
  const refresh = () => { void queryClient.invalidateQueries({ queryKey: ["admin-welcome-slides"] }); void queryClient.invalidateQueries({ queryKey: ["welcome-slides"] }); };
  const uploadImage = async (file: File) => {
    if (file.size > 10 * 1024 * 1024) { toast.error("Image must be under 10MB."); return; }
    setBusy(true);
    try {
      const bytes = new Uint8Array(await file.arrayBuffer()); let binary = "";
      for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
      const result = await upload({ data: { file_name: file.name, content_type: file.type || "image/jpeg", base64: btoa(binary) } });
      setDraft(current => current ? { ...current, image_url: result.image_url } : current); toast.success("Welcome image uploaded");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Upload failed"); } finally { setBusy(false); }
  };
  return <div className="space-y-3">
    <div className="rounded-lg bg-secondary p-3 text-sm text-secondary-foreground">Active slides welcome customers before the catalogue. Lower display-order numbers appear first.</div>
    <Button className="h-12 w-full" onClick={() => setDraft({ headline: "", description: "", image_url: null, button_label: "", button_url: "#catalogue", sort_order: slides.length, is_active: true })}><Plus className="size-4" /> Add carousel slide</Button>
    {draft && <form className="space-y-3 rounded-lg bg-card p-4 shadow-card" onSubmit={async event => { event.preventDefault(); setBusy(true); try { await save({ data: { ...draft, button_label: draft.button_label.trim() || null, button_url: draft.button_url.trim() || null } }); setDraft(null); refresh(); toast.success("Welcome slide saved"); } catch (error) { toast.error(error instanceof Error ? error.message : "Could not save slide"); } finally { setBusy(false); } }}>
      <h2 className="font-bold">{draft.id ? "Edit welcome slide" : "New welcome slide"}</h2>
      {draft.image_url ? <img src={draft.image_url} alt="Welcome slide preview" className="aspect-[2/3] max-h-72 w-full rounded-md object-cover" /> : <div className="grid aspect-[2/3] max-h-56 place-items-center rounded-md bg-muted text-sm text-muted-foreground">Upload a portrait image</div>}
      <label className="inline-flex h-11 cursor-pointer items-center gap-2 rounded-md border border-border px-3 text-sm font-semibold"><ImagePlus className="size-4" />{busy ? "Uploading…" : draft.image_url ? "Change image" : "Upload image"}<input className="hidden" type="file" accept="image/*" onChange={event => { const file = event.target.files?.[0]; if (file) void uploadImage(file); event.target.value = ""; }} /></label>
      <Label>Headline<Input required value={draft.headline} onChange={event => setDraft({ ...draft, headline: event.target.value })} /></Label>
      <Label>Supporting text<Textarea required rows={3} value={draft.description} onChange={event => setDraft({ ...draft, description: event.target.value })} /></Label>
      <Label>Button label (optional)<Input value={draft.button_label} placeholder="Start Shopping" onChange={event => setDraft({ ...draft, button_label: event.target.value })} /></Label>
      <Label>Button action (optional)<Input value={draft.button_url} placeholder="#catalogue or /products/product-id" onChange={event => setDraft({ ...draft, button_url: event.target.value })} /></Label>
      <Label>Display order<Input type="number" value={draft.sort_order} onChange={event => setDraft({ ...draft, sort_order: Number(event.target.value) })} /></Label>
      <label className="flex min-h-11 items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={draft.is_active} onChange={event => setDraft({ ...draft, is_active: event.target.checked })} />Active</label>
      <div className="flex gap-2"><Button disabled={busy} type="submit">Save slide</Button><Button type="button" variant="outline" onClick={() => setDraft(null)}>Cancel</Button></div>
    </form>}
    {isLoading ? <Loader2 className="mx-auto size-5 animate-spin" /> : slides.map(slide => <div key={slide.id} className="flex items-center gap-3 rounded-lg bg-card p-3 shadow-card">
      {slide.image_url ? <img src={slide.image_url} alt="" className="h-20 w-14 rounded object-cover" /> : <div className="h-20 w-14 rounded bg-muted" />}
      <div className="min-w-0 flex-1"><p className="truncate font-semibold">{slide.headline}</p><p className="text-xs text-muted-foreground">{slide.is_active ? "Active" : "Inactive"} · order {slide.sort_order}</p></div>
      <Button size="icon" variant="outline" aria-label={`Edit ${slide.headline}`} onClick={() => setDraft({ id: slide.id, headline: slide.headline, description: slide.description, image_url: slide.image_url, button_label: slide.button_label ?? "", button_url: slide.button_url ?? "#catalogue", sort_order: slide.sort_order, is_active: slide.is_active })}><Pencil className="size-4" /></Button>
      <Button size="icon" variant="outline" aria-label={`Delete ${slide.headline}`} onClick={async () => { if (!window.confirm(`Delete ${slide.headline}?`)) return; try { await remove({ data: { id: slide.id } }); refresh(); toast.success("Welcome slide deleted"); } catch (error) { toast.error(error instanceof Error ? error.message : "Could not delete slide"); } }}><Trash2 className="size-4" /></Button>
    </div>)}
  </div>;
}

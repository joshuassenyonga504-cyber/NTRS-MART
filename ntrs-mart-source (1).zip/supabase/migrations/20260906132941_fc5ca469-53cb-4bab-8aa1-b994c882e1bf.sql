CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC;
GRANT USAGE ON SCHEMA private TO anon, authenticated, service_role;

-- Private admin check (not reachable through the API)
CREATE OR REPLACE FUNCTION private.is_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = 'admin'::public.app_role
  )
$$;

CREATE OR REPLACE FUNCTION private.can_add_items_to_order(_order_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.orders o
    WHERE o.id = _order_id
      AND o.status = 'pending'
      AND (o.user_id IS NULL OR o.user_id = auth.uid())
      AND o.created_at > now() - interval '15 minutes'
  )
$$;

-- Rewire every policy to the private helpers
DROP POLICY IF EXISTS "Admins can manage zones" ON public.delivery_zones;
CREATE POLICY "Admins can manage zones" ON public.delivery_zones FOR ALL TO authenticated
USING (private.is_admin(auth.uid())) WITH CHECK (private.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins can view all products" ON public.products;
CREATE POLICY "Admins can view all products" ON public.products FOR SELECT TO authenticated
USING (private.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Admins can insert products" ON public.products;
CREATE POLICY "Admins can insert products" ON public.products FOR INSERT TO authenticated
WITH CHECK (private.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Admins can update products" ON public.products;
CREATE POLICY "Admins can update products" ON public.products FOR UPDATE TO authenticated
USING (private.is_admin(auth.uid())) WITH CHECK (private.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Admins can delete products" ON public.products;
CREATE POLICY "Admins can delete products" ON public.products FOR DELETE TO authenticated
USING (private.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins can view all orders" ON public.orders;
CREATE POLICY "Admins can view all orders" ON public.orders FOR SELECT TO authenticated
USING (private.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Admins can update orders" ON public.orders;
CREATE POLICY "Admins can update orders" ON public.orders FOR UPDATE TO authenticated
USING (private.is_admin(auth.uid())) WITH CHECK (private.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Admins can delete orders" ON public.orders;
CREATE POLICY "Admins can delete orders" ON public.orders FOR DELETE TO authenticated
USING (private.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins can view all order items" ON public.order_items;
CREATE POLICY "Admins can view all order items" ON public.order_items FOR SELECT TO authenticated
USING (private.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;
CREATE POLICY "Admins can view all roles" ON public.user_roles FOR SELECT TO authenticated
USING (private.is_admin(auth.uid()));

DROP POLICY IF EXISTS "Guests can add order items" ON public.order_items;
CREATE POLICY "Guests can add order items" ON public.order_items FOR INSERT TO anon
WITH CHECK (private.can_add_items_to_order(order_id));
DROP POLICY IF EXISTS "Shoppers can add order items" ON public.order_items;
CREATE POLICY "Shoppers can add order items" ON public.order_items FOR INSERT TO authenticated
WITH CHECK (private.can_add_items_to_order(order_id));

-- Storage policies for product images
DROP POLICY IF EXISTS "Admins can view product images" ON storage.objects;
CREATE POLICY "Admins can view product images" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'product-images' AND private.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Admins can upload product images" ON storage.objects;
CREATE POLICY "Admins can upload product images" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'product-images' AND private.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Admins can update product images" ON storage.objects;
CREATE POLICY "Admins can update product images" ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'product-images' AND private.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Admins can delete product images" ON storage.objects;
CREATE POLICY "Admins can delete product images" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'product-images' AND private.is_admin(auth.uid()));

-- Remove the API-exposed helpers
DROP FUNCTION IF EXISTS public.can_add_items_to_order(uuid);
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);

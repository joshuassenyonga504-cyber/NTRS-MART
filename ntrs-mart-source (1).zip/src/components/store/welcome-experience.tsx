import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { WelcomeSlide } from "@/lib/store-data";
import brandImage from "@/assets/ntrsmart-brand.png.asset.json";

export const WELCOME_SESSION_KEY = "ntrsmart-welcome-session-v2";

type WelcomeExperienceProps = {
  slides: WelcomeSlide[];
  onComplete: () => void;
};

export function WelcomeExperience({ slides, onComplete }: WelcomeExperienceProps) {
  const [index, setIndex] = useState(0);
  const touchStart = useRef<number | null>(null);
  const activeIndex = Math.min(index, Math.max(slides.length - 1, 0));

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  if (slides.length === 0) return null;

  const finish = (buttonUrl?: string | null) => {
    sessionStorage.setItem(WELCOME_SESSION_KEY, "complete");
    onComplete();
    if (!buttonUrl || buttonUrl === "#catalogue") {
      window.requestAnimationFrame(() => {
        document.getElementById("catalogue")?.scrollIntoView({ behavior: "smooth" });
      });
      return;
    }
    if (buttonUrl.startsWith("#")) {
      window.requestAnimationFrame(() => document.querySelector(buttonUrl)?.scrollIntoView({ behavior: "smooth" }));
      return;
    }
    if (buttonUrl.startsWith("/")) {
      window.location.assign(buttonUrl);
      return;
    }
    window.open(buttonUrl, "_blank", "noopener,noreferrer");
  };
  const goTo = (next: number) => setIndex(Math.max(0, Math.min(slides.length - 1, next)));
  const isLast = activeIndex === slides.length - 1;

  return (
    <div
      className="fixed inset-0 z-[100] overflow-hidden bg-primary text-primary-foreground"
      role="dialog"
      aria-modal="true"
      aria-label="Welcome to NTRS.MART"
      onTouchStart={(event) => { touchStart.current = event.touches[0]?.clientX ?? null; }}
      onTouchEnd={(event) => {
        if (touchStart.current === null) return;
        const end = event.changedTouches[0]?.clientX ?? touchStart.current;
        const distance = touchStart.current - end;
        touchStart.current = null;
        if (Math.abs(distance) < 45) return;
        goTo(activeIndex + (distance > 0 ? 1 : -1));
      }}
    >
      <div
        className="flex h-full transition-transform duration-500 ease-out motion-reduce:transition-none"
        style={{ transform: `translateX(-${activeIndex * 100}%)` }}
      >
        {slides.map((slide, slideIndex) => (
          <section
            key={slide.id}
            aria-hidden={slideIndex !== activeIndex}
            inert={slideIndex !== activeIndex}
            className="relative h-full min-w-full overflow-hidden"
          >
            {slide.image_url ? (
              <img
                src={slide.image_url}
                alt=""
                width={1080}
                height={1620}
                loading={slideIndex === 0 ? "eager" : "lazy"}
                className="absolute inset-0 size-full object-cover"
              />
            ) : null}
            <div className="absolute inset-0 bg-[linear-gradient(to_bottom,color-mix(in_oklab,var(--primary)_12%,transparent)_0%,color-mix(in_oklab,var(--primary)_28%,transparent)_38%,color-mix(in_oklab,var(--primary)_94%,transparent)_72%,var(--primary)_100%)]" />

            <div className="relative flex h-full flex-col px-6 pb-[max(2rem,env(safe-area-inset-bottom))] pt-[max(1.25rem,env(safe-area-inset-top))] sm:mx-auto sm:max-w-xl sm:px-10">
              <div className="flex items-start justify-between gap-4">
                <div className="rounded-md bg-background/95 px-3 py-2 shadow-lg">
                  <img src={brandImage.url} alt="NTRS.MART" className="h-11 w-auto max-w-44 object-contain" />
                </div>
                <Button variant="ghost" onClick={() => finish(null)} className="min-h-11 px-3 font-bold text-primary-foreground hover:bg-primary-foreground/15 hover:text-primary-foreground">
                  Skip
                </Button>
              </div>

              <div className="mt-auto max-w-lg pb-3">
                <p className="mb-3 text-xs font-bold uppercase text-accent">Shop · Click · Deliver</p>
                <h2 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">{slide.headline}</h2>
                <p className="mt-4 max-w-md text-base leading-7 text-primary-foreground/90 sm:text-lg">{slide.description}</p>

                {slide.button_label ? (
                  <Button onClick={() => finish(slide.button_url)} variant="secondary" className="mt-7 h-14 w-full rounded-md text-base font-extrabold shadow-xl">
                    {slide.button_label}
                    <ArrowRight className="size-5" />
                  </Button>
                ) : (
                  <Button onClick={() => goTo(activeIndex + 1)} variant="secondary" className="mt-7 h-14 w-full rounded-md text-base font-extrabold shadow-xl">
                    Continue
                    <ArrowRight className="size-5" />
                  </Button>
                )}
              </div>

              <div className="flex min-h-11 items-center justify-between gap-4">
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Previous welcome slide"
                  disabled={activeIndex === 0}
                  onClick={() => goTo(activeIndex - 1)}
                  className="size-11 text-primary-foreground hover:bg-primary-foreground/15 hover:text-primary-foreground"
                >
                  <ArrowLeft />
                </Button>
                <div className="flex items-center gap-2" aria-label={`Slide ${activeIndex + 1} of ${slides.length}`}>
                  {slides.map((item, dotIndex) => (
                    <button
                      key={item.id}
                      type="button"
                      aria-label={`Go to slide ${dotIndex + 1}`}
                      onClick={() => goTo(dotIndex)}
                      className={cn("h-2 rounded-full transition-all", dotIndex === activeIndex ? "w-7 bg-accent" : "w-2 bg-primary-foreground/50")}
                    />
                  ))}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={isLast ? "Enter store" : "Next welcome slide"}
                  onClick={() => isLast ? finish(slide.button_url) : goTo(activeIndex + 1)}
                  className="size-11 text-primary-foreground hover:bg-primary-foreground/15 hover:text-primary-foreground"
                >
                  <ArrowRight />
                </Button>
              </div>
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
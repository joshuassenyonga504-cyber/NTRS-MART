# NTRS.MART Welcome Experience

## Goal
Add a polished, one-time full-screen welcome carousel before the existing storefront. Everything beneath it—catalogue, search, cart, Cash on Delivery checkout, delivery fees, orders, and admin access—stays unchanged.

## What will be built
- A four-slide mobile-first welcome carousel matching the supplied copy:
  1. **Your Trusted Online Mart** with the existing NTRS.MART brand image and **Shop Now**.
  2. **Shop What You Love** with shopping imagery and browse/category messaging.
  3. **Delivered To You** with delivery imagery and automatic delivery-fee messaging.
  4. **Great Products. Great Deals.** with promotional imagery and **Start Shopping**.
- Horizontal touch swiping, smooth transitions, pagination dots, Back/Next controls, and a clear Skip action.
- Full-height phone layouts that respect safe areas, preserve image proportions, and keep copy readable with overlays.
- Completion remembered in browser storage so returning customers go directly to the existing shop.
- A versioned completion key, allowing a future welcome campaign to be shown again without disrupting customer data.

## Admin image and slide management
- Add a **Welcome** tab to the existing admin dashboard.
- Admins can add, edit, reorder, activate/deactivate, and delete welcome slides.
- Each slide supports headline, supporting text, image upload/change, button label, and display order.
- Reuse the existing secure image upload and admin authorization patterns.
- Seed the four requested slides so the opening experience works immediately; the existing NTRS.MART image remains the first-slide identity.

## Data safety
- Extend the current database with one `welcome_slides` table only; do not replace or duplicate existing systems.
- Use public read access only for active slides, with admin-only writes enforced by the current role checks.
- Make the migration idempotent and preserve all products, promotions, carts, orders, delivery zones, and users.

## Verification
- Check first visit, swipe left/right, dots, Skip, Shop Now, and Start Shopping on Android-sized and desktop screens.
- Confirm a returning visit bypasses the welcome carousel and opens the unchanged storefront.
- Confirm admin slide creation/editing, image replacement, ordering, and activation controls.
- Confirm the catalogue, cart, Cash on Delivery checkout, delivery location/fee, and admin Orders still work.
- Run type/build checks and inspect runtime/console errors.

## Technical details
- Keep the carousel inside the existing `/` page so entering the store reveals the current storefront without a route replacement.
- Read browser storage only after hydration to avoid server/client rendering mismatches.
- Use the existing semantic design tokens, Button component, signed image-storage flow, TanStack Query cache, and authenticated server functions.
- Use generated local visual assets for the three supporting slides; no hotlinked images or new integration.

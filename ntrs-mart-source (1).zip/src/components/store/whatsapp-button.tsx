import { MessageCircle } from "lucide-react";
import { whatsappSupportUrl } from "@/lib/whatsapp";
import { cn } from "@/lib/utils";

/**
 * Floating WhatsApp customer-support button.
 * `aboveBar` lifts it above the fixed checkout/cart bottom bar so it
 * never covers important controls.
 */
export function WhatsAppFab({ aboveBar = false }: { aboveBar?: boolean }) {
  return (
    <a
      href={whatsappSupportUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with NTRS.MART on WhatsApp"
      className={cn(
        "fixed right-4 z-40 flex items-center gap-2 rounded-full bg-whatsapp px-4 py-3 text-sm font-bold text-whatsapp-foreground shadow-lg transition active:scale-95",
        aboveBar ? "bottom-28" : "bottom-5",
      )}
    >
      <MessageCircle className="size-5" />
      Need help?
    </a>
  );
}

ALTER TABLE public.welcome_slides
ADD COLUMN IF NOT EXISTS button_url text;

COMMENT ON COLUMN public.welcome_slides.button_url IS 'Optional same-site path, catalogue anchor, or HTTPS URL used by the slide action button.';